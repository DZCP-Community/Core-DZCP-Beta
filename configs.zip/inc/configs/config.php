<?php
/**
 * DZCP - deV!L`z ClanPortal 1.7.0
 * http://www.dzcp.de
 */

#########################################
//-> DZCP Settings Start
#########################################
define('view_error_reporting', true); // Zeigt alle Fehler und Notices etc.
define('view_javascript_debug', false); // Zeigt JavaScript Aufrufe und Infos.
define('debug_all_sql_querys', false); // Speichert alle ausgefuehrten SQL-Querys in einer Datei.
define('debug_save_to_file', false); // Schreibt die die Ausgaben der Debug Console in eine Datei.
define('debug_dzcp_handler', true); // Verwende feur Notices, etc. die Debug Console.
define('fsockopen_support_bypass', false); //Umgeht die fsockopen Pruefung.
define('use_curl', true); // Verwendet die CURL PHP Erweiterung, anstelle von file_get_contents() fur externe Zugriffe, wenn vorhanden.

define('use_default_timezone', true); // Verwendende die Zeitzone vom Web Server.
define('default_timezone', 'Europe/Berlin'); // Die zu verwendende Zeitzone selbst einstellen * 'use_default_timezone' auf false stellen *
define('show_empty_paginator', false); //Die Paginatoren sind immer sichtbar.

define('thumbgen_cache', true); // Sollen die verkleinerten Bilder der Thumbgen gespeichert werden.
define('thumbgen_cache_time', 60*60); // Wie lange sollen die verkleinerten Bilder der Thumbgen im Cache verbleiben.

define('feed_update_time', 10*60); // Wann soll der Newsfeed aktualisiert werden.
define('feed_enable_on_debug', false); // Soll der Newsfeed im Debugmodus generiert werden.
define('file_get_contents_timeout', 10); // Nach wie viel Sekunden soll der Download externer Quellen abgebrochen werden.

define('cookie_expires', (60*60*24*30*12)); // Wie Lange sollen die Cookies des CMS ihre Gueltigkeit behalten.
define('cookie_domain', ''); // Die Domain, der das Cookie zur Verfugung steht.
define('cookie_dir', '/'); // Der Pfad auf dem Server, fur welchen das Cookie verfugbar sein wird.

define('autologin_expire', (14*24*60*60)); // Wie lange sollen die Autologins gultig bleiben, bis zum erneuten Login.

define('captcha_case_sensitive', false); //Unterscheidet Gro� und Kleinschreibung beim Captcha.
define('captcha_mathematic', true); //Stellt den Usern einfache Rechenaufgaben anstelle eines Captcha Codes.
define('captcha_audio_use_sox', false); //Verwendet SoX fuer Captcha Audio Effecte
define('captcha_audio_use_noise', true);
define('captcha_degrade_audio', false);
define('captcha_sox_binary_path', 'sox');

define('count_clicks_expires', (48*60*60)); // Wie Lange die IPs fur den Click-Counter gespeichert bleiben.

define('php_code_enabled', true); // Erlaubt es auf "Adminbereich: Seiten erstellen/verwalten", PHP Code zu verwenden. * Nur Aktivieren wenn es gebaucht wird! *

#########################################
//-> Sessions Settings Start * Expert *
#########################################
define('sessions_backend', 'php'); //Das zu verwendendes Backend: php,mysql,memcache,apc
define('sessions_encode_type', 'sha1'); //Verwende die sha1 codierung fuer session ids
define('sessions_encode', true); //Inhalt der Sessions zusatzlich verschlusseln
define('sessions_ttl_maxtime', (6*60*60)); //Live-Time der Sessions * 2h
define('sessions_memcache_host', '127.0.0.1'); //Server Adresse fur das Sessions Backend: memcache
define('sessions_memcache_port', 11311); //Server Port fur das Sessions Backend: memcache

define('sessions_sql_sethost', false); //Verwende eine externe Datenbank fur die Sessions
define('sessions_sql_driver', 'mysql'); //Welcher Datenbank Treiber soll verwendet werden
define('sessions_sql_host', 'localhost'); //SQL Host
define('sessions_sql_user', 'user'); //SQL Username
define('sessions_sql_pass', 'xxxx'); //SQL Passwort
define('sessions_sql_db', 'test'); //SQL Database

class config {
    /* MYSQL */
    static $SQL_CONNECTION = ["prefix" => "dzcp_",
                                    "driver" => "mysql",
                                    "db_engine" => "default",
                                    "db" => 'dzcp_community',
                                    "db_host" => '192.168.1.1',
                                    "db_user" => 'dzcp',
                                    "db_pw" => '',
                                    "persistent" => true];

    static $rootAdmins = [1];

    static $extensions = ['image/jpeg','image/gif','image/png'];

    static $passwordComponents = ["ABCDEFGHIJKLMNOPQRSTUVWXYZ" , "abcdefghijklmnopqrstuvwxyz" , "0123456789" , "#$@!"];

    static $cryptkey = '1VL%1pG@6GG$';

    static $use_system_cache = true;
    static $use_network_cache = false;
    static $use_less_cache = false;
    static $use_additional_dir = true;

    static $is_memcache = false;
    static $memcache_host = 'localhost';
    static $memcache_port = 11211;
	
	static $smarty_force_compile = true;
    static $smarty_debugging = false;
    static $smarty_caching = false;
    static $smarty_cache_lifetime = 60;
    static $smarty_allow_php_templates = true;

    static $is_redis = false;
    static $redis_host = 'localhost';
    static $redis_port = 7717;
    static $redis_password = '';
    static $redis_database = '';
    static $redis_timeout = '';

    static $upload_dir_permissions = '0755';
    static $upload_file_permissions = '0644';

    static $upload_forbidden_uploads = 'js jsp jsb mhtml mht xhtml xht php phtml php3 php4 php5 phps shtml jhtml pl sh py cgi exe application gadget hta cpl msc jar vb jse ws wsf wsc wsh ps1 ps2 psc1 psc2 msh msh1 msh2 inf reg scf msp scr dll msi vbs bat com pif cmd vxd cpl htpasswd htaccess';
    static $upload_allowed_uploads = '';
}
